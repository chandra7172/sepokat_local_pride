<?php
//include dari config
include_once("../config.php");

//tangkapan berdasarkan id
$id_detail = $_GET['id_detail'];

//syntax hapus pegawai
$result = mysqli_query($mysqli, "DELETE FROM detail_penjualan WHERE id_detail=$id_detail");

//tampilan setelah delete
header("Location: detail_penjualan_read.php");
?>
