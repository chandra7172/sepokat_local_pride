<?php
//merupakan koneksi ke database
//terdiri dari nama server lokal , nama database , nama username , dan password

$databaseHost = 'localhost';
$databaseName = 'sepatu_local_pride';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);

if( !$mysqli ){
    die("Database Gagal Terhubung " . mysqli_connect_error());
}


?>
