<?php
//include dari config
include_once("../config.php");

//tangkapan berdasarkan id
$id_produk = $_GET['id_produk'];

//syntax hapus pegawai
$result = mysqli_query($mysqli, "DELETE FROM master_produk WHERE id_produk=$id_produk");

//tampilan setelah delete
header("Location:produk_read.php");
?>
