<?php
//include koneksi config
include_once("../config.php");

//update pegawai
if(isset($_POST['update']))
{
    $id_produk = $_POST['id_produk'];

    $nama_produk=$_POST['nama_produk'];
    $harga_satuan=$_POST['harga_satuan'];
    


    $result = mysqli_query($mysqli, "UPDATE master_produk SET nama_produk='$nama_produk',harga_satuan='$harga_satuan' WHERE id_produk=$id_produk");


    header("Location: produk_read.php");
}

?>
<?php
// tampilan setelah update
$id_produk = $_GET['id_produk'];

//seleksi berdasarkan id
$result = mysqli_query($mysqli, "SELECT * FROM master_produk WHERE id_produk=$id_produk");

while($user_data = mysqli_fetch_array($result))
{
    $nama_produk = $user_data['nama_produk'];
    $harga_satuan = $user_data['harga_satuan'];
    
}
?>




<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Sepatu Local Pride</title>

    <!-- Bootstrap -->

    
    <link href="../web/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="../web/style2.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <!-- Untuk Container /Header -->
    <div class="container">
      <div id="header">

        <img src="../assets/local_pride.png" class="rounded mx-auto d-block" alt="...">
       
       
        
        
      </div>
    </div>

    <!-- Untuk Navigation -->

    <div class="container">
          <nav class="navbar navbar-default">
      <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="../home.php">Home</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav">
            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Layanan <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="../produk/produk_read.php">Data Produk</a></li>
                <li><a href="../pelanggan/pelanggan_read.php">Data Pelanggan</a></li>
                <li><a href="../penjualan/penjualan_read.php">Data Penjualan</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="../kasir/kasir_read.php">Data Kasir</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="../about.php">About</a></li>
              </ul>
            </li>
          </ul>
          <form class="navbar-form navbar-right">
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Search">
            </div>
            <button type="submit" class="btn btn-default">Cari</button>
          </form>
         
        </div><!-- /.navbar-collapse -->
      </div><!-- /.container-fluid -->
    </nav>
    </div>

    <div class="container">
      <div id="main-content" class="col-sm-12">
          
          <h1><p>Edit Data Produk<p>
              

          </h1>


            <!--  Form Edit-->

                <form name="update_user" method="post" action="produk_edit.php" >
                <div class="form-group">
                  <label >Nama Produk</label>
                  <input type="text" class="form-control" placeholder="Id Produk" name="nama_produk" value=<?php echo $nama_produk;?>>                  
                </div>

                <div class="form-group">
                  <label >Harga Satuan</label>
                  <input type="text" class="form-control" placeholder="Nama Produk" name="harga_satuan" value=<?php echo $harga_satuan;?>>                  
                </div>

                <div class="form-group">
                  
                  <input type="hidden" name="id_produk" value=<?php echo $_GET['id_produk'];?>>                  
                </div>


                
                <button type="submit" class="btn btn-primary" name="update" value="Update">Update</button>
              </form>

              <!--  -->

    

  

            <!--  -->

         
         
      </div>

      <!-- Footer -->
      <footer class="">

  <!-- Copyright -->
        <div class="footer-copyright text-center py-3">© 2020 Copyright:
         <a href="https://mdbootstrap.com/">localpride.com</a>
            </div>
  <!-- Copyright -->

        </footer>
<!-- Footer -->

      
    </div>



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="../web/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../web/bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>

function validasi() {
    var nama = document.getElementById("nama").value;
    var email = document.getElementById("email").value;
    var alamat = document.getElementById("alamat").value;
    if (nama != "" && email!="" && alamat !="") {
      return true;
    }else{
      alert('Anda harus mengisi data dengan lengkap !');
    }
  }