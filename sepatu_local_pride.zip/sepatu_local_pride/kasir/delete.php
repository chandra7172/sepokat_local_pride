<?php
//include dari config
include_once("../config.php");

//tangkapan berdasarkan id
$id_kasir = $_GET['id_kasir'];

//syntax hapus pegawai
$result = mysqli_query($mysqli, "DELETE FROM kasir WHERE id_kasir=$id_kasir");

//tampilan setelah delete
header("Location:kasir_read.php");
?>
