<?php
//include dari config
include_once("../config.php");

//tangkapan berdasarkan id
$id_pelanggan = $_GET['id_pelanggan'];

//syntax hapus pegawai
$result = mysqli_query($mysqli, "DELETE FROM pelanggan WHERE id_pelanggan=$id_pelanggan");

//tampilan setelah delete
header("Location:pelanggan_read.php");
?>
