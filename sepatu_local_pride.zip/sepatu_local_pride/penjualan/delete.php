<?php
//include dari config
include_once("../config.php");

//tangkapan berdasarkan id
$id_penjualan = $_GET['id_penjualan'];

//syntax hapus pegawai
$result = mysqli_query($mysqli, "DELETE FROM header_penjualan WHERE id_penjualan=$id_penjualan");

//tampilan setelah delete
header("Location: penjualan_read.php");
?>
